async function request(){

let terminoBusqueda = document.getElementById("input").value;
const wikiendpoint = `https://en.wikipedia.org/api/rest_v1/page/summary/${terminoBusqueda}`;
const endpoint_ai = "https://api.openai.com/v1/chat/completions";

let response = await fetch(wikiendpoint);
let extract = await response.json();
document.getElementById("wikitext").innerHTML = extract.extract;
        
const opciones = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json','Authorization': 'Bearer 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' },
    body: JSON.stringify({ model: 'gpt-3.5-turbo', messages: [{"role": "user", "content": `Traduce este texto a español ${extract.extract}`}]})
};
        
    let openai_info = fetch(endpoint_ai,opciones).then(

        function (respuesta){
        return respuesta.json();
        }
        
    ).then(
        function (j){
      console.log(j.choices[0].message.content);
      document.getElementById("gpttext").innerHTML = j.choices[0].message.content;
      }
    );
}